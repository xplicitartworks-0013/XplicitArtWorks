XPPLICITARTWORKS WEBSITE
========================

This is a simple, mobile-friendly one-page website.

Files:
- index.html: the complete website (HTML + CSS + small JavaScript)

Free publishing:
1. Create/sign in to a GitHub account at https://github.com
2. Create a new public repository named xplicitartworks
3. Upload index.html to the repository root
4. Open Settings > Pages
5. Under Build and deployment, choose Deploy from a branch
6. Choose branch main and folder /(root), then Save
7. Wait for GitHub Pages to publish. Your free URL will look like:
   https://YOUR-USERNAME.github.io/xplicitartworks/

Before publishing:
- Replace the "Contact details coming soon" area with your public WhatsApp number, email, or social links.
- Replace sample portfolio tiles with your actual project images when ready.

No paid hosting or custom domain is required.
